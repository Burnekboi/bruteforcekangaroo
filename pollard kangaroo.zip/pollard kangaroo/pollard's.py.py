import hashlib
import base58
import ecdsa
import secrets
import time

# Global variables
found_target = None

def convert_pvk_hex_to_bitcoin_address(hex_private_key):
    # Step 1: Convert the hex private key to bytes
    private_key_bytes = bytes.fromhex(hex_private_key)

    # Step 2: Derive the public key using ecdsa
    signing_key = ecdsa.SigningKey.from_string(private_key_bytes, curve=ecdsa.SECP256k1)
    verifying_key = signing_key.get_verifying_key()
    compressed_public_key = verifying_key.to_string("compressed").hex()

    # Step 3: Perform SHA-256 hashing on the compressed public key
    sha256_hash = hashlib.sha256(bytes.fromhex(compressed_public_key)).digest()

    # Step 4: Perform RIPEMD-160 hashing
    ripemd160 = hashlib.new('ripemd160')
    ripemd160.update(sha256_hash)
    ripemd160_result = ripemd160.digest()

    # Step 5: Add version byte (0x00 for Main Network)
    extended_ripemd160 = bytes.fromhex('00') + ripemd160_result

    # Step 6: Perform double SHA-256 hashing
    hash1 = hashlib.sha256(extended_ripemd160).digest()
    hash2 = hashlib.sha256(hash1).digest()

    # Step 7: Take the first 4 bytes of the double SHA-256 hash as checksum
    checksum = hash2[:4]

    # Step 8: Add the checksum to the extended RIPEMD-160 hash
    binary_address = extended_ripemd160 + checksum

    # Step 9: Perform Base58Check encoding
    bitcoin_address = base58.b58encode(binary_address).decode('utf-8')

    return bitcoin_address

def pollards_kangaroo(target_address, start_private_key, end_private_key):
    global found_target

    start_time = time.time()
    x_slow = int(start_private_key, 16)
    x_fast = int(start_private_key, 16)
    jump_size = 3

    try:
        while found_target is None and x_slow <= int(end_private_key, 16):
            private_key_slow = format(x_slow, '064x')  # Convert x_slow to a 64-character hexadecimal string
            private_key_fast = format(x_fast, '064x')  # Convert x_fast to a 64-character hexadecimal string

            # Calculate Bitcoin addresses for both slow and fast keys
            address_slow = convert_pvk_hex_to_bitcoin_address(private_key_slow)
            address_fast = convert_pvk_hex_to_bitcoin_address(private_key_fast)

            if address_fast == target_address:
                found_target = (private_key_fast, address_fast)
                break

            if address_slow == target_address:
                found_target = (private_key_slow, address_slow)
                break

            x_slow += jump_size
            x_fast += 10 * jump_size  # Fast kangaroo jumps twice as fast as the slow one

            if x_slow > int(end_private_key, 16):
                print(f"Target not found in the specified range.")
                break

    except KeyboardInterrupt:
        print("\nManually terminated.")
        return

    if found_target is not None:
        private_key, address = found_target
        print(f"Target found: {address} (Private Key: {private_key})")

    elapsed_time = time.time() - start_time
    keys_per_second = (x_slow - int(start_private_key, 16)) / elapsed_time
    total_searched_keys = x_slow - int(start_private_key, 16) + 1
    print(f"Elapsed time: {elapsed_time:.2f} seconds | Speed: {keys_per_second:.2f} keys/second | Total Searched: {total_searched_keys}")

if __name__ == "__main__":
    print("Bitcoin Address and Private Key Tool with Pollard's Kangaroo Algorithm")

    while True:
        print("\nOptions:")
        print("1. Generate Bitcoin Address from Private Key")
        print("2. Use Pollard's Kangaroo Algorithm to Find Private Key for Target Address")
        print("3. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            hex_private_key = input("Enter the hexadecimal private key: ").strip()
            bitcoin_address = convert_pvk_hex_to_bitcoin_address(hex_private_key)
            print(f"Bitcoin Address: {bitcoin_address}")

        elif choice == '2':
            target_address = input("Enter the target Bitcoin address: ").strip()
            start_private_key = input("Enter the starting private key (hexadecimal): ").strip()
            end_private_key = input("Enter the ending private key (hexadecimal): ").strip()
            found_target = None
            pollards_kangaroo(target_address, start_private_key, end_private_key)

        elif choice == '3':
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please choose a valid option.")
